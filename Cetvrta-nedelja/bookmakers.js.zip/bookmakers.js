"strict mode";

function Country (cName, odds, continent){
    this.cName = cName;
    this.odds = odds;
    this.continent = continent;
};

var continents = {
    EUROPE: "EU",
    AUSTRALIA: "AU",
    AFRICA: "AF",
    SOUTHAMERICA: "SA",
    NORTHAMERICA: "NA",
    ASIA: "AS",
};

Object.freeze(continents);

function Person (name, surname, dateOfBirth){
    this.name = name;
    this.surname = surname;
    this.dateOfBirth = dateOfBirth;
}

function Player (name, surname, betAmount, cName, odds, continent);{
this.person = new Person(name, surname, dateOfBirth);
this.betAmount = betAmount;
this.country = new Country(cName, odds, continent);
}

function Address (cName, odds, continent, city, postalCode, street, number);{
this.country = country;
this.postalCode = postalCode;
this.street = street;
this.number = number;
}

function BettingPlace (cName, odds, continent, city, postalCode, street, number){
    this.address = new Address(country, city, postalCode, street, number);
    this.listOfPlayers = [];
}

function BettingHouse (competition){
    this.competition = competition;
    this.listOfPlayers = [];
    this.numberOfPlayers = 0;
}




(function(){
    
    }());